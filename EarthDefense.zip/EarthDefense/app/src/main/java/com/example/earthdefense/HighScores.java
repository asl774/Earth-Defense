package com.example.earthdefense;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;

public class HighScores extends Activity implements OnClickListener {
    Context context;
    EarthDefenseActivity earthDefenseActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.high_scores);
        setTitle("Your Score: " + EarthDefenseView.score + "  High Score: " + EarthDefenseView.highScore);

        context = getApplicationContext();
        View replayButton = findViewById(R.id.replay_button);
        View anotherLevelButton = findViewById(R.id.another_level_button);
        View mainMenuButton = findViewById(R.id.main_menu_button);
        replayButton.setOnClickListener(this);
        anotherLevelButton.setOnClickListener(this);
        mainMenuButton.setOnClickListener(this);
        setFinishOnTouchOutside(false);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.replay_button:
                finish();
                break;
            case R.id.another_level_button:
                Intent intent = new Intent(context, SelectLevel.class);
                context.startActivity(intent);
                finish();
                break;
            case R.id.main_menu_button:
                EarthDefense.getInstance().finish();
                finish();
                break;
        }
    }

}
