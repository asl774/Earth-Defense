package com.example.earthdefense;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Bullet {
    private float x;
    private float y;

    // The player ship will be represented by a Bitmap
    private Bitmap bitmap;

    // How long and high our ship will be
    private float length;
    private float height;
    private int width = 1;
    RectF rect;

    // Which way projectile is shooting
    public final int UP = 0;
    public final int DOWN = 1;
    public final int LEFT = 2;
    public final int RIGHT = 3;
    public final int UPLEFT = 4;
    public final int UPRIGHT = 5;
    public final int DOWNLEFT = 6;
    public final int DOWNRIGHT = 7;

    // Going nowhere
    private int heading = -1;
    private float speed =  1600; //1500 for normal, 100 for test, 400 for moderate, 800 moderate, 1200 fast, 1600 very fast, 2000 lightning

    private boolean isActive;
    private boolean isVisible;

    public Bullet(Context context, int screenX, int screenY) {

        // Initialize a blank RectF
        rect = new RectF();

        length = screenX / 12;
        height = screenY / 20;

        isVisible = true;
        isActive = false;

        if (!EarthDefense.getZombieModeOn()) {
            // Initialize the bitmap
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.orb1);
        }
        else {
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.finalbullet);
        }
        // Stretch the first bitmap to a size appropriate for the screen resolution
        bitmap = Bitmap.createScaledBitmap(bitmap,
                (int) (length),
                (int) (height),
                false);
    }

    public RectF getRect(){
        return  rect;
    }

    public Bitmap getBitmap(){
        return bitmap;
    }

    public float getX(){
        return x;
    }

    public float getY(){
        return y;
    }

    public float getHeight(){
        return height;
    }

    public boolean getStatus(){
        return isActive;
    }

    public void setInactive(){
        isActive = false;
    }

    public float getImpactPointY(){
        if (heading == DOWN){
            return y + height;
        }
        else{
            return  y;
        }
    }

    public float getImpactPointX(){
        if (heading == RIGHT){
            return x + height;
        }
        else{
            return  x;
        }
    }

    public boolean shoot(float startX, float startY, int direction) {
        if (!isActive) {
            x = startX;
            y = startY;
            heading = direction;
            isActive = true;
            return true;
        }

        // Bullet already active
        return false;
    }

    public void update(long fps){

        if(heading == UP){
            y = y - speed / fps;
        }
        else if(heading == DOWN){
            y = y + speed / fps;
        }
        else if(heading == LEFT){
            x = x - speed / fps;
        }
        else if(heading == RIGHT){
            x = x + speed / fps;
        }

        else if(heading == UPLEFT){
            y = y - speed / fps;
            x = x - (speed * 2/3) / fps;
        }
        else if(heading == UPRIGHT){
            y = y - speed / fps;
            x = x + (speed * 2/3) / fps;
        }
        else if(heading == DOWNLEFT){
            y = y + speed / fps;
            x = x - (speed * 2/3) / fps;
        }
        else if(heading == DOWNRIGHT){
            y = y + speed / fps;
            x = x + (speed * 2/3) / fps;
        }

        // Update rect
        rect.left = x;
        rect.right = x + width;
        rect.top = y;
        rect.bottom = y + height;
    }

}
