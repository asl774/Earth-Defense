package com.example.earthdefense;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

// EarthDefenseActivity is the entry point to the game.
// It will display the menu along with all the options available.
public class EarthDefenseActivity extends AppCompatActivity implements View.OnClickListener {

    private static int[] ids = {R.id.about_button, R.id.exit_button, R.id.new_button};
    private static final String TAG = "EarthDefenseActivity";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        View[] buttons = new View[ids.length];
        for(int i = 0; i < buttons.length; i++) {
            buttons[i] = findViewById(ids[i]);
            buttons[i].setOnClickListener(this);
        }
    }

    public void onClick(View v) {
        Sounds.play(this, R.raw.bing2);

        switch (v.getId()) {
            case R.id.about_button:
                Intent i = new Intent(this, About.class);
                startActivity(i);
                break;
            case R.id.new_button:
                openNewGameDialog();
                break;
            case R.id.exit_button:
                finish();
                break;
        }
    }

    private void openNewGameDialog() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this);
        adb.setTitle(R.string.new_game_title);
        adb.setItems(R.array.difficulty,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int difficulty) {
                        startGame(difficulty);	// callback!
                    }
                });
        adb.show();
    }

    private void startGame(int difficulty) {
        Log.d(TAG, "clicked on " + difficulty);
        Intent intent = new Intent(this, EarthDefense.class);
        intent.putExtra(EarthDefense.KEY_DIFFICULTY, difficulty);
        startActivity(intent);
    }

}