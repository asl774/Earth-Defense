package com.example.earthdefense;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Invader {
    RectF rect;

    // The player ship will be represented by a Bitmap
    private Bitmap bitmap1;
    private Bitmap bitmap2;

    // How long and high our alien ship will be
    private float length;
    private float height;

    // X is the far left of the rectangle which forms our alien ship
    private float x;

    // Y is the top coordinate
    private float y;

    // This will hold the pixels per second speed that the alien ship will move
    private float shipSpeed;

    public final int LEFT = 1;
    public final int RIGHT = 2;
    public final int DOWN = 3;
    public final int UP = 4;
    public final int DOWNLEFT = 5;
    public final int DOWNRIGHT = 6;
    public final int UPLEFT = 7;
    public final int UPRIGHT = 8;

    // Is the ship moving and in which direction
    private int shipMoving = DOWN;

    boolean isVisible;
    boolean isHit;

    public Invader(Context context, int screenX, int screenY){
        
        // Initialize a blank RectF
        rect = new RectF();

        length = screenX/6;
        height = screenY/10;

        // Ship start point
        x = screenX / 2 - 100;
        y = screenY / 2;

        // Initialize the bitmap
        if (!EarthDefense.getZombieModeOn()) {
            bitmap1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.alienship);
            bitmap2 = BitmapFactory.decodeResource(context.getResources(), R.drawable.explode);
        }
        else {
            bitmap1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.finalzombie);
            bitmap2 = BitmapFactory.decodeResource(context.getResources(), R.drawable.finalblood);
        }
        // How fast is the spaceship in pixels per second
        shipSpeed = 100;
    }

    public void setInvisible(){
        isVisible = false;
    }

    public void setVisible(){
        isVisible = true;
    }

    public boolean getVisibility(){
        return isVisible;
    }

    public boolean getHit(){
        return isHit;
    }

    public void setHit(){
        isHit = true;
    }

    public RectF getRect(){
        return rect;
    }

    public Bitmap getBitmap(){
        return bitmap1;
    }

    public Bitmap getBitmap2(){
        return bitmap2;
    }

    public float getX(){
        return x;
    }

    public float getY(){
        return y;
    }

    public void setShipMoving(int direction) { shipMoving = direction; }

    public void setShipSpeed(float speed) { shipSpeed = speed; }

    public void update(long fps){
        if(shipMoving == LEFT){
            x = x - shipSpeed / fps;
        }

        else if(shipMoving == RIGHT){
            x = x + shipSpeed / fps;
        }

        else if(shipMoving == DOWN){
            y = y + shipSpeed / fps;
        }

        else if(shipMoving == UP){
            y = y - shipSpeed / fps;
        }

        else if(shipMoving == DOWNLEFT){
            y = y + shipSpeed / fps;
            x = x - (shipSpeed * 2/3) / fps;
        }

        else if(shipMoving == DOWNRIGHT){
            y = y + shipSpeed / fps;
            x = x + (shipSpeed * 2/3) / fps;
        }

        else if(shipMoving == UPLEFT){
            y = y - shipSpeed / fps;
            x = x - (shipSpeed * 2/3) / fps;
        }

        else if(shipMoving == UPRIGHT){
            y = y - shipSpeed / fps;
            x = x + (shipSpeed * 2/3) / fps;
        }

        // Update rect which is used to detect hits
        rect.top = y + 90;      //add    60
        rect.bottom = y + 180;  //sub    190
        rect.left = x - 60;     //add    -60  -40
        rect.right = x + 290;   //sub    290  +250
    }
}
