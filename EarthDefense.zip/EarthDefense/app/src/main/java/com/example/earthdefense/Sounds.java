package com.example.earthdefense;

import android.content.Context;
import android.media.MediaPlayer;
import android.util.Log;

public class Sounds {

    static MediaPlayer thePlayer;
    private static int length;
    private static String TAG = "Sounds";

    public static void play(Context context, int resourceID) {
        stop();
        Log.d(TAG, "trying to play sound: " + resourceID + ", context: " + context);
        try {
            thePlayer = MediaPlayer.create(context, resourceID);

            thePlayer.start();
        }
        catch(Exception e) {
            Log.d(TAG, "Enable to play sound! " + e);
        }
    }

    public static void pause(){
        if (thePlayer != null) {
            length = thePlayer.getCurrentPosition();
            thePlayer.pause();
        }
    }

    public static void resume(){
        if (thePlayer != null) {
            length = thePlayer.getCurrentPosition();
            thePlayer.seekTo(length);
            thePlayer.start();
        }
    }

    public static void stop() {
        if(thePlayer != null) {
            thePlayer.stop();
            thePlayer.reset();
            thePlayer.release();
            thePlayer = null;
        }
    }

    public static void mute() {
        thePlayer.setVolume(0,0);
    }

    public static void unMute() {
        thePlayer.setVolume(1,1);
    }

}
