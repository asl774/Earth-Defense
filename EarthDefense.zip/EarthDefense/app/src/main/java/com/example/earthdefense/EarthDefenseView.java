package com.example.earthdefense;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.SoundPool;
import android.support.v4.view.GestureDetectorCompat;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class EarthDefenseView extends SurfaceView implements Runnable, GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener {
    private static final String TAG = "EarthDefenseView";

    Context context;

    // The game thread
    private Thread gameThread = null;

    // The surface holder
    private SurfaceHolder ourHolder;

    // Boolean to determine is game is playing or not
    private volatile boolean playing;

    // Booleans indicating game statuses
    private boolean paused = true;
    private boolean gameOver = false;
    private boolean playerWon = false;
    private boolean playerLost = false;

    // Canvas and paint needed for drawing
    private Canvas canvas;
    private Paint paint;
    private Paint paint2;

    // Game frame rate
    private long fps;

    // Helps calculate fps
    private long timeThisFrame;

    // The size of the screen in pixels
    private int screenX;
    private int screenY;

    // The players ship aka the Earth
    private PlayerShip playerShip;

    // The player's bullets aka the blue projectiles
    private Bullet[] playerBullets = new Bullet[100];
    private int nextPlayerBullet;
    private int maxPlayerBullets = 100;

    // Initializing the alien ship array
    int scoreToWin = 100;
    Invader[] invaders = new Invader[scoreToWin + 20];
    int numInvaders = 0;
    float speedEASY = 120;      //120
    float speedNORMAL = 150;    //150
    float speedHARD = 180;      //180

    static int score = 0;
    static int highScore = 0;

    // Used to change position of alien ships
    private int adjustX = 0;
    private int adjustY = 0;

    // Sounds
    private SoundPool soundPool;
    private int playerExplodeID = -1;
    private int invaderExplodeID = -1;
    private int shootID = -1;
    private int bgMusic = -1;

    // The gesture detector
    private GestureDetectorCompat mDetector;

    public EarthDefenseView(Context context, int x, int y) {

        super(context);
        this.context = context;

        mDetector = new GestureDetectorCompat(context, this);
        mDetector.setOnDoubleTapListener(this);

        ourHolder = getHolder();
        paint = new Paint();
        paint2 = new Paint();

        screenX = x;
        screenY = y;

        soundPool = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        shootID = soundPool.load(context, R.raw.projectile, 0);
        playerExplodeID = soundPool.load(context, R.raw.explode, 0);
        invaderExplodeID = soundPool.load(context, R.raw.implode, 0);
        bgMusic = R.raw.track5;

        prepareLevel();

    }

    private void prepareLevel() {
        Sounds.stop();
        soundPool.release();
        soundPool = null;
        soundPool = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        shootID = soundPool.load(context, R.raw.projectile, 0);
        playerExplodeID = soundPool.load(context, R.raw.explode, 0);
        invaderExplodeID = soundPool.load(context, R.raw.implode, 0);
        bgMusic = R.raw.track5;

        gameOver = false;
        playerLost = false;
        playerWon = false;

        adjustX = 0;
        adjustY = 0;
        score = 0;

        // Here we will initialize all the game objects
        // Make a new player space ship
        playerShip = new PlayerShip(context, screenX, screenY);

        // Initialize the playerBullets array
        for (int i = 0; i < playerBullets.length; i++) {
            playerBullets[i] = new Bullet(context, screenX, screenY);
        }

        invaders = new Invader[scoreToWin + 20];
        buildInvaderShips();

        Sounds.play(context, bgMusic);
        if(!EarthDefense.getMusicOn())
            Sounds.mute();

        paused = true;
    }

    private void buildInvaderShips() {

            // Build invaders RIGHT
            numInvaders = 0;

            for (int i = 0; i < invaders.length / 8; i++) {
                invaders[i] = new Invader(context, 3100 + adjustX, screenY - 500 + adjustY);
                invaders[i].setShipMoving(1);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX += 700;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders LEFT
            adjustX = 0;
            for (int i = invaders.length / 8; i < invaders.length / 4; i++) {
                invaders[i] = new Invader(context, -500 + adjustX, screenY - 500 + adjustY);
                invaders[i].setShipMoving(2);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX -= 700;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders DOWN
            adjustX = 0;
            for (int i = invaders.length / 4; i < invaders.length / 8 * 3; i++) {
                invaders[i] = new Invader(context, screenX - 140 + adjustX, 4300 + adjustY);
                invaders[i].setShipMoving(4);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustY += 500;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders UP
            adjustY = 0;
            for (int i = invaders.length / 8 * 3; i < invaders.length / 2; i++) {
                invaders[i] = new Invader(context, screenX - 140 + adjustX, -550 + adjustY);
                invaders[i].setShipMoving(3);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustY -= 500;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders UPRIGHT
            adjustX = 0;
            adjustY = 0;
            for (int i = invaders.length / 2; i < invaders.length / 8 * 5; i++) {
                invaders[i] = new Invader(context, 3100 + adjustX, -550 + adjustY);
                invaders[i].setShipMoving(5);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX += 333;
                adjustY -= 500;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders UPLEFT
            adjustX = 0;
            adjustY = 0;
            for (int i = invaders.length / 8 * 5; i < invaders.length / 8 * 6; i++) {
                invaders[i] = new Invader(context, -500 + adjustX, -550 + adjustY);
                invaders[i].setShipMoving(6);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX -= 333;
                adjustY -= 500;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders DOWNRIGHT
            adjustX = 0;
            adjustY = 0;
            for (int i = invaders.length / 8 * 6; i < invaders.length / 8 * 7; i++) {
                invaders[i] = new Invader(context, 3100 + adjustX, 4300 + adjustY);
                invaders[i].setShipMoving(7);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX += 333;
                adjustY += 500;
                numInvaders++;
                invaders[i].setVisible();
            }

            // Build invaders DOWNLEFT
            adjustX = 0;
            adjustY = 0;
            for (int i = invaders.length / 8 * 7; i < invaders.length; i++) {
                invaders[i] = new Invader(context, -500 + adjustX, 4300 + adjustY);
                invaders[i].setShipMoving(8);
                if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                    invaders[i].setShipSpeed(speedEASY);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                    invaders[i].setShipSpeed(speedNORMAL);
                else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                    invaders[i].setShipSpeed(speedHARD);
                adjustX -= 333;
                adjustY += 500;
                numInvaders++;
                invaders[i].setVisible();
            }
        }

    @Override
    public void run() {
        while (playing) {

            // Capture the current time in milliseconds in startFrameTime
            long startFrameTime = System.currentTimeMillis();

            // Update the frame
            if (!paused) {
                update();
            }

            // Draw the frame
            draw();

            // Calculate the fps this frame
            // We can then use the result to
            // time animations and more.
            timeThisFrame = System.currentTimeMillis() - startFrameTime;
            if (timeThisFrame >= 1) {
                fps = 1000 / timeThisFrame;
            }

        }
    }

    private void update() {

        if (!gameOver) {

            // Update Earth
            playerShip.update();

            // Update the alien ships if visible
            for (int i = 0; i < numInvaders; i++) {
                if (invaders[i].getVisibility() && !invaders[i].getHit())
                    invaders[i].update(fps);
            }

            // Update projectiles
            for (int i = 0; i < playerBullets.length; i++) {
                if (playerBullets[i].getStatus())
                    playerBullets[i].update(fps);
            }

            // Has the player's bullet hit top of screen
            for (int i = 0; i < playerBullets.length; i++) {
                if (playerBullets[i].getImpactPointY() < 0 || playerBullets[i].getImpactPointY() > screenY
                        || playerBullets[i].getImpactPointX() < 0 || playerBullets[i].getImpactPointX() > screenX) {
                    playerBullets[i].setInactive();
                }
            }

            // Has alien ships hit Earth
            for (int i = 0; i < numInvaders; i++) {
                if (invaders[i].getVisibility()) {
                    if (RectF.intersects(invaders[i].getRect(), playerShip.getRect())) {
                        playerShip.setHit();
                        if (EarthDefense.getSoundOn())
                        soundPool.play(playerExplodeID, 1, 1, 0, 0, 1);
                        gameOver = true;
                        playerLost = true;
                        if (score > highScore)
                            highScore = score;
                        Intent intent = new Intent(context, HighScores.class);
                        context.startActivity(intent);
                    }
                }
            }

            // Has any projectiles hit an alien ship
            for (int i = 0; i < playerBullets.length; i++) {
                if (playerBullets[i].getStatus()) {
                    for (int j = 0; j < numInvaders; j++) {
                        if (invaders[j].getVisibility() && !invaders[j].getHit()) {
                            if (RectF.intersects(playerBullets[i].getRect(), invaders[j].getRect())) {
                                invaders[j].setHit();
                                if (EarthDefense.getSoundOn())
                                soundPool.play(invaderExplodeID, 1, 1, 0, 0, 1);
                                playerBullets[i].setInactive();
                                score = score + 1;

                                // Has the player won
                                if (score >= scoreToWin) {
                                    gameOver = true;
                                    playerWon = true;
                                    if (score > highScore)
                                        highScore = score;
                                    Intent intent = new Intent(context, HighScores.class);
                                    context.startActivity(intent);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void draw () {
        // Make sure our drawing surface is valid or we crash
        if (ourHolder.getSurface().isValid()) {
            // Lock the canvas ready to draw
            canvas = ourHolder.lockCanvas();

            // Draw the background color
            canvas.drawColor(getResources().getColor(R.color.gameBackground));

            // Choose the brush color for drawing
            paint.setColor(Color.argb(255, 255, 255, 255));
            paint2.setColor(Color.argb(255, 255, 255, 255));

            // Draw the Earth
            canvas.drawBitmap(playerShip.getBitmap(), playerShip.getX(), playerShip.getY(), paint);

            // Draw alien ships
            for(int i = 0; i < numInvaders; i++){
                if(invaders[i].getVisibility()) {
                    if(invaders[i].getHit()) {
                        canvas.drawBitmap(invaders[i].getBitmap2(), invaders[i].getX(), invaders[i].getY(), paint2);
                        invaders[i].setInvisible();
                    }
                    else {
                        canvas.drawBitmap(invaders[i].getBitmap(), invaders[i].getX(), invaders[i].getY(), paint);
                    }
                }
            }

            //Draws "dead" Earth if Earth is hit by alien ship
            if (!gameOver) {
            if(playerShip.getHit()) {
                canvas.drawBitmap(playerShip.getBitmap2(), playerShip.getX(), playerShip.getY(), paint);
            }

            // Draw projectiles
            for (int i = 0; i < playerBullets.length; i++) {
                if (playerBullets[i].getStatus()) {
                    canvas.drawBitmap(playerBullets[i].getBitmap(), playerBullets[i].getX(), playerBullets[i].getY(), paint);
                }
                }
            }

            // Change the brush color
            paint.setColor(getResources().getColor(R.color.gameGreen));

            paint.setTextSize(100);

            // Draw the score and difficulty level
            canvas.drawText("Score: " + score, 10, 80, paint);
            if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_EASY)
                canvas.drawText("Level: " + "EASY", 910, 80, paint);
            else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_NORMAL)
                canvas.drawText("Level: " + "NORMAL", 740, 80, paint);
            else if (EarthDefense.getDifficulty() == EarthDefense.DIFFICULTY_HARD)
                canvas.drawText("Level: " + "HARD", 890, 80, paint);

            //Draws paused text
            if ((paused && !gameOver)){
                canvas.drawText("PAUSED", screenX / 2 - 180, screenY / 2 - 260, paint);
                canvas.drawText("TAP TO START", screenX / 2 - 310, screenY / 2 + 80, paint);
            }

            //Draws level cleared text
            if (gameOver){
                if (playerWon) {
                    canvas.drawText("LEVEL CLEARED", screenX / 2 - 340, screenY / 2 - 260, paint);
                    canvas.drawText("TAP TO START", screenX / 2 - 310, screenY / 2 + 80, paint);
                }

                //Draws game over text
                else if (playerLost) {
                    canvas.drawText("GAME OVER", screenX / 2 - 272, screenY / 2 - 260, paint);
                    canvas.drawText("TAP TO START", screenX / 2 - 310, screenY / 2 + 80, paint);
                }

            }

            // Draw everything to the screen
            ourHolder.unlockCanvasAndPost(canvas);
        }
    }

    // If EarthDefense is paused/stopped
    // shutdown our thread.
    public void pause() {
        playing = false;
        try {
            gameThread.join();
        } catch (InterruptedException e) {
            Log.e("Error:", "joining thread");
        }
        if (EarthDefense.getSoundOn() || EarthDefense.getMusicOn())
        Sounds.pause();
    }

    // If EarthDefense is started then
    // start our thread.
    public void resume() {
        playing = true;
        gameThread = new Thread(this);
        gameThread.start();
        if (EarthDefense.getMusicOn())
            Sounds.unMute();
            Sounds.resume();
    }


    // The SurfaceView class implements onTouchListener
    // So we can override this method and detect screen touches.
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        paused = false;
        if (this.mDetector.onTouchEvent(motionEvent)) {
            return true;
        }
        if (gameOver)
            return false;

        return true;
    }

    @Override
    public boolean onDown(MotionEvent event) {
        if (gameOver) {
           for (int i = 0; i < invaders.length; i++)
               invaders[i].setInvisible();
            prepareLevel();
        }
            Log.d(TAG, "onDown: " + event.toString());
        switch (event.getAction() & MotionEvent.ACTION_MASK) {

            // Player has touched the screen
            case MotionEvent.ACTION_DOWN:
                paused = false;
                if (!gameOver && playing && !EarthDefense.getMachineGunOn() && EarthDefense.getTapModeOn()) {

                    //UPRIGHT
                    if (event.getY() < screenY / 3 && event.getX() > screenX / 3 * 2) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 + 25, screenY / 2 - 300, playerBullets[nextPlayerBullet].UPRIGHT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //UPLEFT
                    else if (event.getY() < screenY / 3 && event.getX() < screenX / 3) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 - 140, screenY / 2 - 300, playerBullets[nextPlayerBullet].UPLEFT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //DOWNRIGHT
                    else if (event.getY() > screenY / 3 * 2 && event.getX() > screenX / 3 * 2) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 + 40, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNRIGHT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //DOWNLEFT
                    else if (event.getY() > screenY / 3 * 2 && event.getX() < screenX / 3) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 - 150, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNLEFT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //RIGHT
                    else if (event.getX() > screenX / 3 * 2) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 + 75, (screenY / 2) - 170, playerBullets[nextPlayerBullet].RIGHT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //LEFT
                    else if (event.getX() < screenX / 3) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 - 190, (screenY / 2) - 170, playerBullets[nextPlayerBullet].LEFT)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //UP
                    else if (event.getY() < screenY / 3) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 - 60, screenY / 2 - 320, playerBullets[nextPlayerBullet].UP)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    //DOWN
                    else if (event.getY() > screenY / 3 * 2) {
                        if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                                playerShip.getLength() / 2 - 60, screenY / 2 - 60, playerBullets[nextPlayerBullet].DOWN)) {
                            nextPlayerBullet++;
                            if (nextPlayerBullet == maxPlayerBullets) {
                                nextPlayerBullet = 0;
                            }
                            if (EarthDefense.getSoundOn())
                            soundPool.play(shootID, 1, 1, 0, 0, 1);
                        }
                    }
                    break;
                }
        }
        return true;
    }

    @Override
    public boolean onFling(MotionEvent event1, MotionEvent event2,
                           float velocityX, float velocityY) {
        // Grab two events located on the plane at e1=(x1, y1) and e2=(x2, y2)
        // Let e1 be the initial event
        // e2 can be located at 4 different positions, consider the following diagram
        // (Assume that lines are separated by 90 degrees.)
        //
        //
        //      D  \ C  /   B
        //      ----\  /----
        //      E  event1   A
        //      ----/  \-----
        //      F  / G  \   H
        //
        // So if (x2,y2) falls in region:
        //  A => RIGHT
        //  B => UPRIGHT
        //  C => UP
        //  D => UPLEFT
        //  E => LEFT
        //  F => DOWNLEFT
        //  G => DOWN
        //  H => DOWNRIGHT

            float x1 = event1.getX();
            float y1 = event1.getY();

            float x2 = event2.getX();
            float y2 = event2.getY();

            Direction direction = getDirection(x1, y1, x2, y2);
            return onSwipe(direction);
    }

    /** Override this method. The Direction enum will tell you how the user swiped. */
    public boolean onSwipe(Direction direction){
        return false;
    }

    /**
     * Given two points in the plane p1=(x1, x2) and p2=(y1, y1), this method
     * returns the direction that an arrow pointing from p1 to p2 would have.
     * @param x1 the x position of the first point
     * @param y1 the y position of the first point
     * @param x2 the x position of the second point
     * @param y2 the y position of the second point
     * @return the direction
     */
    public Direction getDirection(float x1, float y1, float x2, float y2){
        double angle = getAngle(x1, y1, x2, y2);
        if (!gameOver && playing && !paused && !EarthDefense.getMachineGunOn() && !EarthDefense.getTapModeOn()) {
            if (Direction.get(angle) == Direction.upleft) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 140, screenY / 2 - 250, playerBullets[nextPlayerBullet].UPLEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.upright) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 25, screenY / 2 - 250, playerBullets[nextPlayerBullet].UPRIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.downleft) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 150, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNLEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.downright) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 40, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNRIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.left) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 190, (screenY / 2) - 170, playerBullets[nextPlayerBullet].LEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.right) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 75, (screenY / 2) - 170, playerBullets[nextPlayerBullet].RIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.up) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 60, screenY / 2 - 300, playerBullets[nextPlayerBullet].UP)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.down) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 60, screenY / 2 - 60, playerBullets[nextPlayerBullet].DOWN)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                    soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }
        }
        return Direction.get(angle);
    }

    public Direction getDirection2(float x1, float y1, float x2, float y2){
        double angle = getAngle(x1, y1, x2, y2);
        if (!gameOver && playing && !paused && EarthDefense.getMachineGunOn()) {
            if (Direction.get(angle) == Direction.upleft) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 140, screenY / 2 - 250, playerBullets[nextPlayerBullet].UPLEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.upright) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 25, screenY / 2 - 250, playerBullets[nextPlayerBullet].UPRIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.downleft) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 150, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNLEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.downright) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 40, screenY / 2 - 100, playerBullets[nextPlayerBullet].DOWNRIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.left) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 190, (screenY / 2) - 170, playerBullets[nextPlayerBullet].LEFT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.right) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 + 75, (screenY / 2) - 170, playerBullets[nextPlayerBullet].RIGHT)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.up) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 60, screenY / 2 - 300, playerBullets[nextPlayerBullet].UP)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }

            else if (Direction.get(angle) == Direction.down) {
                if (playerBullets[nextPlayerBullet].shoot(playerShip.getX() +
                        playerShip.getLength() / 2 - 60, screenY / 2 - 60, playerBullets[nextPlayerBullet].DOWN)) {
                    nextPlayerBullet++;
                    if (nextPlayerBullet == maxPlayerBullets) {
                        nextPlayerBullet = 0;
                    }
                    if (EarthDefense.getSoundOn())
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                }
            }
        }
        return Direction.get(angle);
    }

    /**
     *
     * Finds the angle between two points in the plane (x1,y1) and (x2, y2)
     * The angle is measured with 0/360 being the X-axis to the right, angles
     * increase counter clockwise.
     *
     * @param x1 the x position of the first point
     * @param y1 the y position of the first point
     * @param x2 the x position of the second point
     * @param y2 the y position of the second point
     * @return the angle between two points
     */
    public double getAngle(float x1, float y1, float x2, float y2) {

        double rad = Math.atan2(y1-y2,x2-x1) + Math.PI;
        return (rad*180/Math.PI + 180)%360;
    }

    public enum Direction{
        up,
        down,
        left,
        right,
        upleft,
        upright,
        downleft,
        downright;

        /**
         * Returns a direction given an angle.
         * Directions are defined as follows:
         *
         * Up: [45, 135]
         * Right: [0,45] and [315, 360]
         * Down: [225, 315]
         * Left: [135, 225]
         *
         * @param angle an angle from 0 to 360 - e
         * @return the direction of an angle
         */
        public static Direction get(double angle){
            if(inRange(angle, 15,60)){
                return Direction.upright;
            }
            else if(inRange(angle, 60, 105)){
                return Direction.up;
            }
            else if(inRange(angle, 105, 150)){
                return Direction.upleft;
            }
            else if(inRange(angle, 150, 195)){
                return Direction.left;
            }
            else if(inRange(angle, 195, 240)){
                return Direction.downleft;
            }
            else if(inRange(angle, 240, 285)){
                return Direction.down;
            }
            else if (inRange(angle, 285, 330)){
                return Direction.downright;
            }
            else
                return Direction.right;
        }

        /**
         * @param angle an angle
         * @param init the initial bound
         * @param end the final bound
         * @return returns true if the given angle is in the interval [init, end).
         */
        private static boolean inRange(double angle, float init, float end){
            return (angle >= init) && (angle < end);
        }
    }

    @Override
    public void onLongPress(MotionEvent event) {
        if (!gameOver)
        Log.d(TAG, "onLongPress: " + event.toString());
    }

    @Override
    public boolean onScroll(MotionEvent event1, MotionEvent event2, float distanceX,
                            float distanceY) {
        float x1 = event1.getX();
        float y1 = event1.getY();

        float x2 = event2.getX();
        float y2 = event2.getY();

        Direction direction = getDirection2(x1, y1, x2, y2);
        return onSwipe(direction);
    }

    @Override
    public void onShowPress(MotionEvent event) {
        if (!gameOver)
            Log.d(TAG, "onShowPress: " + event.toString());
    }

    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        if (!gameOver)
            Log.d(TAG, "onSingleTapUp: " + event.toString());
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent event) {
        if (!gameOver)
        Log.d(TAG, "onDoubleTap: " + event.toString());
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent event) {
        if (!gameOver)
        Log.d(TAG, "onDoubleTapEvent: " + event.toString());
        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent event) {
        if (!gameOver)
        Log.d(TAG, "onSingleTapConfirmed: " + event.toString());
        return true;
    }

}