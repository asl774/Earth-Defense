package com.example.earthdefense;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class EarthDefense extends AppCompatActivity {
    static EarthDefense activityA;
    public static final String KEY_DIFFICULTY = "com.example.EarthDefenseView";
    public static int difficulty;
    public static final int DIFFICULTY_EASY = 0;
    public static final int DIFFICULTY_NORMAL = 1;
    public static final int DIFFICULTY_HARD = 2;

    private static final int SETTINGS_REQUEST = 0;
    private static boolean mSoundOn;
    private static boolean mMusicOn;
    private static boolean mMachineGunOn;
    private static boolean mTapModeOn;
    private static boolean mZombieModeOn;
    private boolean isPaused = false;
    private boolean isPausedSettings = false;
    private Menu menu;
    private MenuItem item1, item2;

    EarthDefenseView earthDefenseView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        activityA = this;
        super.onCreate(savedInstanceState);
        setInstanceVarsFromSharedPrefs();
        difficulty = getIntent().getIntExtra(KEY_DIFFICULTY, DIFFICULTY_NORMAL);

        // Get a Display object to access screen details
        Display display = getWindowManager().getDefaultDisplay();

        // Load the resolution into a Point object
        Point size = new Point();
        display.getSize(size);

        // Initialize gameView and set it as the view
        earthDefenseView = new EarthDefenseView(this, size.x, size.y);
        setContentView(earthDefenseView);

        // allow volume control:
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }

    public static EarthDefense getInstance(){
        return activityA;
    }

    private void setInstanceVarsFromSharedPrefs () {
        SharedPreferences sharedPref = getPreferences(MODE_PRIVATE);
        mMusicOn = sharedPref.getBoolean("music", false);
        mSoundOn = sharedPref.getBoolean("sounds", false);
        mTapModeOn = sharedPref.getBoolean("tapmode", false);
        mMachineGunOn = sharedPref.getBoolean("machinegun", false);
        mZombieModeOn = sharedPref.getBoolean("zombiemode", false);
    }

    public static boolean getSoundOn(){
        return mSoundOn;
    }

    public static boolean getMusicOn(){
        return mMusicOn;
    }

    public static boolean getMachineGunOn(){
        return mMachineGunOn;
    }

    public static boolean getTapModeOn(){
        return mTapModeOn;
    }

    public static boolean getZombieModeOn(){
        return mZombieModeOn;
    }

    public static int getDifficulty(){
        return difficulty;
    }

    public static void setDifficulty(int diff){
        difficulty = diff;
    }

    // This method executes when the player starts the game
    @Override
    protected void onResume() {

        super.onResume();
        if (getMusicOn())
            Sounds.unMute();
        else
            Sounds.mute();
            Sounds.resume();

        // Tell the gameView resume method to execute
        earthDefenseView.resume();
    }

    // This method executes when the player quits the game
    @Override
    protected void onPause() {
        super.onPause();
        Sounds.pause();

        // Tell the gameView pause method to execute
        earthDefenseView.pause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Sounds.pause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        this.menu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        earthDefenseView.pause();

        switch (item.getItemId()) {
            case R.id.pause:
                if (!isPaused) {
                    earthDefenseView.pause();
                    isPaused = true;
                    item.setIcon(R.drawable.play);
                }
                else {
                    earthDefenseView.resume();
                    isPaused = false;
                    item.setIcon(R.drawable.pause);
                }
                break;
            case R.id.settings:
                earthDefenseView.pause();
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivityForResult(intent, SETTINGS_REQUEST);
                item1 = menu.findItem(R.id.pause);
                item1.setIcon(R.drawable.pause);
                isPaused = false;
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data){
        if (requestCode == SETTINGS_REQUEST) {
            SharedPreferences sharedPref = getPreferences(MODE_PRIVATE);
            mMusicOn = sharedPref.getBoolean("music", false);
            mSoundOn = sharedPref.getBoolean("sounds", false);
            mTapModeOn = sharedPref.getBoolean("tapmode", false);
            mMachineGunOn = sharedPref.getBoolean("machinegun", false);
            mZombieModeOn = sharedPref.getBoolean("zombiemode", false);
        }
    }

}
