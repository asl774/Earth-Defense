package com.example.earthdefense;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import static com.example.earthdefense.EarthDefense.DIFFICULTY_EASY;
import static com.example.earthdefense.EarthDefense.DIFFICULTY_HARD;
import static com.example.earthdefense.EarthDefense.DIFFICULTY_NORMAL;
import static com.example.earthdefense.EarthDefense.setDifficulty;

public class SelectLevel extends Activity implements OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_level);

        View easyButton = findViewById(R.id.easy_button);
        View normalButton = findViewById(R.id.normal_button);
        View hardButton = findViewById(R.id.hard_button);
        easyButton.setOnClickListener(this);
        normalButton.setOnClickListener(this);
        hardButton.setOnClickListener(this);
        setFinishOnTouchOutside(false);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.easy_button:
                setDifficulty(DIFFICULTY_EASY);
                finish();
                break;
            case R.id.normal_button:
                setDifficulty(DIFFICULTY_NORMAL);
                finish();
                break;
            case R.id.hard_button:
                setDifficulty(DIFFICULTY_HARD);
                finish();
                break;
        }
    }

}
